import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { User } from "@supabase/supabase-js";
import {
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/AppSidebar";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Sparkles, Save, Database } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

const Dashboard = () => {
  const [user, setUser] = useState<User | null>(null);
  const [selectedBusiness, setSelectedBusiness] = useState<string | null>(null);
  const [selectedBusinessName, setSelectedBusinessName] = useState<string>("");
  const [customBusinessName, setCustomBusinessName] = useState<string>("");
  const [prompt, setPrompt] = useState("");
  const [voiceType, setVoiceType] = useState<string>("alloy");
  const [loading, setLoading] = useState(false);
  const [backupLoading, setBackupLoading] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (!session) {
        navigate("/auth");
      } else {
        setUser(session.user);
      }
    });

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      if (!session) {
        navigate("/auth");
      } else {
        setUser(session.user);
      }
    });

    return () => subscription.unsubscribe();
  }, [navigate]);

  const getSamplePrompt = (businessName: string) => {
    const prompts: { [key: string]: string } = {
      "Dental Clinic": "You are a friendly AI booking agent for a dental clinic. Greet patients warmly and help them schedule appointments. Ask about:\n- Type of service needed (cleaning, checkup, emergency)\n- Preferred date and time\n- Any dental concerns or pain\n- Insurance information\nConfirm all details before finalizing the booking.",
      "Hair Salon": "You are a professional AI booking agent for a hair salon. Help clients book appointments by asking:\n- Desired service (haircut, coloring, styling, treatment)\n- Preferred stylist (if any)\n- Date and time preference\n- Hair length and type\nBe friendly and suggest suitable time slots.",
      "Medical Practice": "You are a caring AI booking agent for a medical practice. Assist patients with scheduling by:\n- Understanding their health concern\n- Checking urgency level\n- Finding available appointment slots\n- Collecting patient information\n- Confirming insurance details\nMaintain a professional and empathetic tone.",
      "Restaurant": "You are a welcoming AI booking agent for a restaurant. Help guests make reservations by asking:\n- Number of guests\n- Preferred date and time\n- Special occasions or dietary requirements\n- Seating preferences (indoor/outdoor)\nSuggest popular time slots and confirm details.",
      "Spa & Wellness": "You are a soothing AI booking agent for a spa. Help clients book treatments by:\n- Discussing available services (massage, facial, body treatment)\n- Understanding their wellness goals\n- Suggesting treatment durations\n- Finding convenient appointment times\nMaintain a calm and relaxing communication style.",
    };
    return prompts[businessName] || "";
  };

  const handleBusinessSelect = async (businessId: string, businessName: string) => {
    setSelectedBusiness(businessId);
    setSelectedBusinessName(businessName);
    
    // Load existing prompt and business name if available
    if (user) {
      const { data } = await supabase
        .from("prompts")
        .select("prompt_text, business_name, voice_type")
        .eq("user_id", user.id)
        .eq("business_id", businessId)
        .single();
      
      if (data) {
        setPrompt(data.prompt_text);
        setCustomBusinessName(data.business_name || "");
        setVoiceType(data.voice_type || "alloy");
      } else {
        // Set sample prompt for new business selection
        setPrompt(getSamplePrompt(businessName));
        setCustomBusinessName("");
        setVoiceType("alloy");
      }
    }
  };

  const handleSavePrompt = async () => {
    if (!user || !selectedBusiness || !prompt.trim()) {
      toast({
        title: "Error",
        description: "Please select a business and enter a prompt",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    try {
      const { error } = await supabase.from("prompts").upsert({
        user_id: user.id,
        business_id: selectedBusiness,
        prompt_text: prompt,
        business_name: customBusinessName.trim() || null,
        voice_type: voiceType,
        is_active: true,
      });

      if (error) throw error;

      toast({
        title: "Success",
        description: "Configuration saved successfully",
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleBackup = async () => {
    if (!user) return;

    setBackupLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('backup-database');

      if (error) throw error;

      toast({
        title: "Backup Initiated",
        description: "Database backup will be sent to your email shortly",
      });
    } catch (error: any) {
      toast({
        title: "Backup Failed",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setBackupLoading(false);
    }
  };

  return (
    <SidebarProvider>
      <div className="min-h-screen w-full flex">
        <AppSidebar onBusinessSelect={handleBusinessSelect} />
        
        <div className="flex-1 flex flex-col">
          <header className="h-14 md:h-16 border-b border-border bg-card flex items-center justify-between px-4 md:px-6">
            <div className="flex items-center">
              <SidebarTrigger />
              <h1 className="ml-2 md:ml-4 text-base md:text-xl font-semibold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent truncate">
                AI Booking Agent Builder
              </h1>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={handleBackup}
              disabled={backupLoading}
            >
              <Database className="mr-2 h-4 w-4" />
              {backupLoading ? "Backing up..." : "Backup to Email"}
            </Button>
          </header>

          <main className="flex-1 p-4 md:p-6 overflow-auto">
            {selectedBusiness ? (
              <div className="max-w-4xl mx-auto space-y-4 md:space-y-6">
                <div>
                  <h2 className="text-xl md:text-2xl font-bold mb-2 flex items-center gap-2">
                    <Sparkles className="h-5 w-5 md:h-6 md:w-6 text-primary" />
                    Configure {customBusinessName || selectedBusinessName} Agent
                  </h2>
                  <p className="text-muted-foreground">
                    Customize your business name and AI agent's behavior
                  </p>
                </div>

                <Card className="p-4 md:p-6 space-y-4 md:space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="businessName">Your Business Name</Label>
                    <Input
                      id="businessName"
                      placeholder={`e.g., "My ${selectedBusinessName} Practice"`}
                      value={customBusinessName}
                      onChange={(e) => setCustomBusinessName(e.target.value)}
                      className="text-lg"
                    />
                    <p className="text-sm text-muted-foreground">
                      Enter your actual business name (e.g., "Elite Dental Care" for a dental clinic)
                    </p>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="agentInstructions">AI Agent Instructions</Label>
                    <Textarea
                      id="agentInstructions"
                      placeholder={`Enter custom instructions for your booking agent...`}
                      value={prompt}
                      onChange={(e) => setPrompt(e.target.value)}
                      className="min-h-[300px] font-mono"
                    />
                    <p className="text-sm text-muted-foreground">
                      Sample prompt has been added based on your business type. Feel free to customize it!
                    </p>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="voiceType">Voice Selection</Label>
                    <select
                      id="voiceType"
                      value={voiceType}
                      onChange={(e) => setVoiceType(e.target.value)}
                      className="w-full px-3 py-2 border border-input bg-background rounded-md focus:outline-none focus:ring-2 focus:ring-ring"
                    >
                      <option value="alloy">Alloy (Neutral)</option>
                      <option value="echo">Echo (Male)</option>
                      <option value="fable">Fable (Male, British)</option>
                      <option value="onyx">Onyx (Male, Deep)</option>
                      <option value="nova">Nova (Female, Young)</option>
                      <option value="shimmer">Shimmer (Female, Warm)</option>
                    </select>
                    <p className="text-sm text-muted-foreground">
                      Choose the voice type for your AI booking agent
                    </p>
                  </div>

                  <Button
                    onClick={handleSavePrompt}
                    disabled={loading}
                    className="w-full"
                  >
                    <Save className="mr-2 h-4 w-4" />
                    {loading ? "Saving..." : "Save Configuration"}
                  </Button>
                </Card>

                <Card className="p-6 bg-gradient-to-br from-primary/5 to-secondary/5">
                  <h3 className="font-semibold mb-2 flex items-center gap-2">
                    <Sparkles className="h-5 w-5 text-primary" />
                    Need Help?
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    Our AI assistant can help you create the perfect booking agent configuration. 
                    Just describe what you want and we'll help you build it!
                  </p>
                </Card>
              </div>
            ) : (
              <div className="h-full flex items-center justify-center">
                <div className="text-center space-y-4">
                  <Sparkles className="h-16 w-16 text-primary mx-auto" />
                  <h2 className="text-2xl font-bold">Select a Business Type</h2>
                  <p className="text-muted-foreground max-w-md">
                    Choose a business type from the sidebar to start configuring your AI booking agent
                  </p>
                </div>
              </div>
            )}
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
};

export default Dashboard;
