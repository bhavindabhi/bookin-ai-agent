import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useNavigate } from "react-router-dom";
import { Sparkles, Zap, Shield, TrendingUp } from "lucide-react";

const Index = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-b from-background via-background to-primary/5">
      {/* Hero Section */}
      <header className="pt-20 pb-16 px-6 text-center">
        <div className="max-w-5xl mx-auto space-y-8">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
            <Sparkles className="h-4 w-4" />
            AI-Powered Booking System
          </div>
          
          <h1 className="text-6xl font-bold mb-6 bg-gradient-to-r from-primary via-primary to-secondary bg-clip-text text-transparent">
            BookingAI Pro
          </h1>
          
          <p className="text-2xl text-muted-foreground mb-8 max-w-3xl mx-auto">
            Transform your business with AI booking agents that work 24/7. 
            Perfect for dental clinics, salons, restaurants, and more.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button
              size="lg"
              onClick={() => navigate("/auth?mode=demo")}
              className="text-lg px-8 py-6 bg-gradient-to-r from-primary to-secondary hover:opacity-90"
            >
              Try Free Demo
            </Button>
            <Button
              size="lg"
              variant="outline"
              onClick={() => navigate("/license")}
              className="text-lg px-8 py-6"
            >
              Get License
            </Button>
          </div>
        </div>
      </header>

      {/* Features Section */}
      <section className="max-w-6xl mx-auto px-6 py-16">
        <div className="grid md:grid-cols-4 gap-6">
          <Card className="p-6 bg-gradient-to-br from-card to-primary/5 hover:shadow-lg transition-shadow">
            <Sparkles className="h-10 w-10 text-primary mb-4" />
            <h3 className="font-semibold text-lg mb-2">AI-Powered</h3>
            <p className="text-sm text-muted-foreground">
              Advanced AI understands customer needs and books appointments intelligently
            </p>
          </Card>

          <Card className="p-6 bg-gradient-to-br from-card to-secondary/5 hover:shadow-lg transition-shadow">
            <Zap className="h-10 w-10 text-secondary mb-4" />
            <h3 className="font-semibold text-lg mb-2">24/7 Availability</h3>
            <p className="text-sm text-muted-foreground">
              Never miss a booking - your AI agent works round the clock
            </p>
          </Card>

          <Card className="p-6 bg-gradient-to-br from-card to-primary/5 hover:shadow-lg transition-shadow">
            <Shield className="h-10 w-10 text-primary mb-4" />
            <h3 className="font-semibold text-lg mb-2">Secure & Reliable</h3>
            <p className="text-sm text-muted-foreground">
              Enterprise-grade security for your business data
            </p>
          </Card>

          <Card className="p-6 bg-gradient-to-br from-card to-secondary/5 hover:shadow-lg transition-shadow">
            <TrendingUp className="h-10 w-10 text-secondary mb-4" />
            <h3 className="font-semibold text-lg mb-2">Boost Revenue</h3>
            <p className="text-sm text-muted-foreground">
              Increase bookings by 40% with automated, always-on service
            </p>
          </Card>
        </div>
      </section>

      {/* Business Types */}
      <section className="max-w-6xl mx-auto px-6 py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Perfect for Any Business</h2>
          <p className="text-muted-foreground">
            Our AI booking agents work across multiple industries
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
          {[
            { icon: "🦷", name: "Dental" },
            { icon: "🏥", name: "Medical" },
            { icon: "💇", name: "Salons" },
            { icon: "🍽️", name: "Restaurants" },
            { icon: "💆", name: "Spa" },
            { icon: "💪", name: "Fitness" },
            { icon: "🏨", name: "Hotels" },
            { icon: "⚖️", name: "Legal" },
            { icon: "🚗", name: "Auto" },
            { icon: "💼", name: "Consulting" },
          ].map((business) => (
            <Card
              key={business.name}
              className="p-4 text-center hover:shadow-md transition-shadow cursor-pointer"
            >
              <div className="text-3xl mb-2">{business.icon}</div>
              <p className="text-sm font-medium">{business.name}</p>
            </Card>
          ))}
        </div>
      </section>

      {/* CTA Section */}
      <section className="max-w-4xl mx-auto px-6 py-16">
        <Card className="p-12 bg-gradient-to-br from-primary/10 to-secondary/10 text-center">
          <h2 className="text-3xl font-bold mb-4">
            Ready to Transform Your Business?
          </h2>
          <p className="text-lg text-muted-foreground mb-8">
            Join hundreds of businesses already using our AI booking system
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              size="lg"
              onClick={() => navigate("/auth?mode=demo")}
              className="bg-gradient-to-r from-primary to-secondary hover:opacity-90"
            >
              Start Free Demo
            </Button>
            <Button
              size="lg"
              variant="outline"
              onClick={() => navigate("/auth")}
            >
              Sign In
            </Button>
          </div>
        </Card>
      </section>
    </div>
  );
};

export default Index;
