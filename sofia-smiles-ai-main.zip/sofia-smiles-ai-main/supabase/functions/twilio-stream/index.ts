import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.7.1';

const OPENAI_API_KEY = Deno.env.get('OPENAI_API_KEY');
const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
const SUPABASE_ANON_KEY = Deno.env.get('SUPABASE_ANON_KEY')!;

serve(async (req) => {
  // Validate API key
  if (!OPENAI_API_KEY) {
    console.error("OPENAI_API_KEY is not configured");
    return new Response("Server configuration error", { status: 500 });
  }
  
  console.log("OPENAI_API_KEY is configured, length:", OPENAI_API_KEY.length);
  
  try {
    const upgrade = req.headers.get("upgrade") || "";
    
    if (upgrade.toLowerCase() !== "websocket") {
      return new Response("Expected websocket", { status: 426 });
    }

    // Get user_id from query params to load custom business name
    const url = new URL(req.url);
    const userId = url.searchParams.get("user_id");
    
    let businessName = "Complete Smiles Dental Practice in Harrow"; // Default
    
    if (userId) {
      const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
      const { data } = await supabase
        .from('prompts')
        .select('business_name')
        .eq('user_id', userId)
        .eq('is_active', true)
        .single();
      
      if (data?.business_name) {
        businessName = data.business_name;
        console.log("Loaded custom business name:", businessName);
      }
    }

    const { socket, response } = Deno.upgradeWebSocket(req);
    
    let openAiWs: WebSocket | null = null;
    let streamSid: string | null = null;
    let sessionConfigured = false;

    socket.onopen = async () => {
      console.log("Twilio WebSocket connected");
      
      // Set up keepalive ping every 30 seconds to prevent timeout
      const keepAliveInterval = setInterval(() => {
        if (socket.readyState === WebSocket.OPEN) {
          console.log("Sending keepalive ping to Twilio");
        }
        if (openAiWs && openAiWs.readyState === WebSocket.OPEN) {
          console.log("Sending keepalive ping to OpenAI");
          openAiWs.send(JSON.stringify({ type: "ping" }));
        }
      }, 30000); // Every 30 seconds
      
      try {
        console.log("Requesting ephemeral token from OpenAI...");
        const tokenResponse = await fetch("https://api.openai.com/v1/realtime/sessions", {
          method: "POST",
          headers: {
            "Authorization": `Bearer ${OPENAI_API_KEY}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            model: "gpt-4o-realtime-preview-2024-12-17",
            voice: "alloy"
          }),
        });

        console.log("Token response status:", tokenResponse.status);
        
        if (!tokenResponse.ok) {
          const errorText = await tokenResponse.text();
          console.error("OpenAI API error:", errorText);
          throw new Error(`Failed to get token: ${tokenResponse.status}`);
        }

        const tokenData = await tokenResponse.json();
        const ephemeralKey = tokenData.client_secret?.value;

        if (!ephemeralKey) {
          throw new Error("No ephemeral token received");
        }

        // Connect to OpenAI Realtime API
        const model = "gpt-4o-realtime-preview-2024-12-17";
        const url = `wss://api.openai.com/v1/realtime?model=${model}`;
        
        console.log("Connecting to OpenAI Realtime API...");
        openAiWs = new WebSocket(url, [
          "realtime",
          `openai-insecure-api-key.${ephemeralKey}`,
          "openai-beta.realtime-v1"
        ]);

        openAiWs.onopen = () => {
          console.log("Connected to OpenAI - waiting for session.created");
        };

        openAiWs.onmessage = (event) => {
          try {
            const data = JSON.parse(event.data);
            console.log("OpenAI event:", data.type);
            
            // Configure session after it's created
            if (data.type === "session.created" && !sessionConfigured) {
              console.log("Session created - configuring session");
              sessionConfigured = true;
              
              const sessionUpdate = {
                type: "session.update",
                session: {
                  turn_detection: { type: "server_vad" },
                  input_audio_format: "g711_ulaw",
                  output_audio_format: "g711_ulaw",
                  voice: "alloy",
                  instructions: `You are Sofia, a warm and friendly AI receptionist for ${businessName}. You speak naturally like a helpful friend while maintaining professionalism.

GREETING:
When answering the call, ALWAYS start with: "Hello, ${businessName}. How may I assist you?"

Be conversational and friendly, using natural language like "That's wonderful!", "Perfect!", "I'd be happy to help with that!"

CRITICAL COMMUNICATION RULES:
1. ALWAYS wait for the caller to finish speaking completely before responding
2. Listen carefully to ALL information - never interrupt or assume
3. Speak naturally and conversationally, like a friendly professional
4. Pause briefly between sentences
5. If you miss something, say: "I'm sorry, I didn't catch that. Could you repeat it for me?"
6. NEVER end the call or disconnect - always stay patient and wait for corrections
7. If caller provides wrong information, stay calm and ask politely for the correct details
8. Keep conversations going smoothly - there's no time limit on calls

MULTILINGUAL SUPPORT:
You speak fluent English, Portuguese (European & Brazilian), Spanish, French, Italian, German, Polish, and Romanian. If caller speaks another language, switch immediately with a warm greeting.

BOOKING APPOINTMENTS - CONVERSATIONAL APPROACH:

1. First, understand what they need:
   "What can I help you with today?" 
   Listen for: new appointment, emergency, specific service needed.

2. Collect information naturally, ONE piece at a time:

   NAME:
   "May I have your full name please?"
   Wait for response. Confirm: "Thank you, [Name]."

   PHONE NUMBER (CRITICAL VALIDATION - BE PATIENT):
   "What's the best phone number to reach you?"
   - Phone number MUST be exactly 10 digits
   - If they give 9 digits or wrong number, say GENTLY:
     "I apologize, but I need exactly 10 digits for the phone number to complete your booking. No worries at all - could you please provide that 10-digit number for me? Take your time."
   - If they make a mistake, NEVER rush them or sound frustrated
   - Stay on the line patiently and wait for them to provide the correct number
   - Once received, confirm by reading it back digit by digit:
     "Let me confirm that number: [read each digit slowly and clearly]. Is that correct?"
   - If they say no, ask: "No problem! What's the correct number?"

   EMAIL (EXTREMELY CRITICAL - USE PHONETIC ALPHABET):
   "And what's your email address?"
   - Listen to the ENTIRE email address without interrupting
   - After they finish, say: "Let me confirm that exactly. I'll spell it back to you using the phonetic alphabet."
   - Spell it back using NATO phonetic alphabet (Alpha, Bravo, Charlie, Delta, Echo, Foxtrot, etc.)
     Example: "So that's Juliet-Oscar-Hotel-November dot Sierra-Mike-India-Tango-Hotel at Golf-Mike-Alpha-India-Lima dot Charlie-Oscar-Mike. Is that correct?"
   - If they say it's wrong, say: "I apologize for the error. Please spell out your email address slowly, letter by letter."
   - WAIT for them to spell it completely
   - Repeat back using phonetic alphabet: "Thank you! So that's [spell each letter using phonetic alphabet]. Is that 100% correct?"
   - Do NOT proceed until they explicitly confirm YES
   - NEVER move to the next step until email is 100% verified

   SERVICE:
   "What type of appointment would you like to book?"
   Options: General Check-up, Hygiene Cleaning, Invisalign Consultation, Dental Implants, Teeth Whitening, or Emergency Care
   
   DATE & TIME:
   "When would work best for you? I can offer you [suggest 2-3 specific dates]"
   Then: "What time would suit you? We have morning, afternoon, or early evening slots."

3. Confirm everything warmly:
   "Perfect! Let me just confirm everything with you:
   - Your name is [full name]
   - Phone number: [read each digit]
   - Email: [spell out entire email character by character]
   - You're booking a [service type]
   - For [date] at [time]
   Does that all sound correct?"

4. After confirmation:
   "Brilliant! Your appointment is all confirmed. You'll receive a confirmation email shortly at [spell out email again]. Is there anything else I can help you with today?"

HANDLING CORRECTIONS AND MISTAKES - STAY PATIENT:
If they say something is wrong or made a mistake:
- NEVER sound frustrated or impatient
- Say cheerfully: "No problem at all! Let's get that corrected. What should it be?"
- Wait patiently for their response
- Stay on the line even if they take time to find the information
- Say: "Take your time, I'm here whenever you're ready"
- NEVER disconnect or end the call prematurely
- Calls can last as long as needed - there's no time limit

CANCELLATIONS/CHANGES:
"I'd be happy to help with that! May I have your full name and phone number so I can find your appointment?"
After changes: "All sorted! I've updated your appointment and you'll receive a new confirmation email."

EMERGENCY CASES:
If caller mentions pain, swelling, bleeding, or broken tooth:
"Oh, I'm really sorry to hear that! Let me check our earliest emergency slot for you today. If we can't fit you in immediately, please do call NHS 111 for urgent dental care - they're available 24/7."

PROFESSIONAL BUT FRIENDLY:
- Use natural phrases: "Absolutely!", "That works perfectly!", "I've got that noted down"
- Be empathetic: "I understand", "That must be uncomfortable"
- Stay patient: "Take your time", "No rush at all", "Whenever you're ready"
- Always repeat critical info (phone digit by digit, email CHARACTER BY CHARACTER, dates)
- Never show frustration if caller makes mistakes
- Remember: Calls can take as long as needed

ENDING CALLS:
"Thank you so much for calling ${businessName}! Your appointment is confirmed for [date] at [time], and you'll receive an email confirmation shortly at [spell out email]. We're looking forward to seeing you! Have a wonderful day!"

Remember: Be friendly, accurate, thorough, and EXTREMELY PATIENT. If caller provides wrong info or makes mistakes, stay calm and cheerful. NEVER disconnect or rush them. Quality over speed. Make every caller feel valued and heard. There is NO TIME LIMIT on calls - take as long as needed to get everything perfect.`,
                  modalities: ["text", "audio"],
                  temperature: 0.8,
                }
              };
              
              openAiWs?.send(JSON.stringify(sessionUpdate));
              console.log("Session configuration sent");
            }
            
            // Confirm session updated
            if (data.type === "session.updated") {
              console.log("Session configured successfully");
            }
            
            // Forward audio to Twilio
            if (data.type === "response.audio.delta" && data.delta && streamSid) {
              const twilioMessage = {
                event: "media",
                streamSid: streamSid,
                media: {
                  payload: data.delta
                }
              };
              socket.send(JSON.stringify(twilioMessage));
            }
            
            // Log other important events
            if (data.type === "response.audio_transcript.delta") {
              console.log("Transcript:", data.delta);
            }
            
            if (data.type === "error") {
              console.error("OpenAI error:", data);
            }
          } catch (error) {
            console.error("Error processing OpenAI message:", error);
          }
        };

        openAiWs.onerror = (error) => {
          console.error("OpenAI WebSocket error:", error);
        };

        openAiWs.onclose = () => {
          console.log("OpenAI WebSocket closed");
          clearInterval(keepAliveInterval);
        };

      } catch (error) {
        console.error("Error connecting to OpenAI:", error);
        socket.close();
      }
    };

    socket.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        
        switch (data.event) {
          case "start":
            streamSid = data.start.streamSid;
            console.log("Twilio stream started:", streamSid);
            break;
            
          case "media":
            // Forward audio from Twilio to OpenAI
            if (openAiWs && openAiWs.readyState === WebSocket.OPEN) {
              const audioAppend = {
                type: "input_audio_buffer.append",
                audio: data.media.payload
              };
              openAiWs.send(JSON.stringify(audioAppend));
            }
            break;
            
          case "stop":
            console.log("Twilio stream stopped");
            openAiWs?.close();
            break;
        }
      } catch (error) {
        console.error("Error processing Twilio message:", error);
      }
    };

    socket.onclose = () => {
      console.log("Twilio WebSocket closed");
      openAiWs?.close();
    };

    socket.onerror = (error) => {
      console.error("Twilio WebSocket error:", error);
      openAiWs?.close();
    };

    return response;
  } catch (error) {
    console.error("Error in twilio-stream function:", error);
    return new Response("Internal Server Error", { status: 500 });
  }
});
