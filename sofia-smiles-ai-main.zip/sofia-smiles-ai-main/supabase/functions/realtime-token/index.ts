import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log("Requesting ephemeral token from OpenAI...");
    
    const OPENAI_API_KEY = Deno.env.get('OPENAI_API_KEY');
    if (!OPENAI_API_KEY) {
      throw new Error('OPENAI_API_KEY is not configured');
    }

    // Request ephemeral token for OpenAI Realtime API
    const response = await fetch("https://api.openai.com/v1/realtime/sessions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${OPENAI_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "gpt-4o-realtime-preview-2024-12-17",
        voice: "alloy",
        instructions: `You are Sofia, the friendly and professional AI receptionist for Complete Smiles Dental Practice in Harrow.

You are multilingual and can communicate fluently in English, Portuguese (both European and Brazilian), Spanish, French, Italian, German, Polish, and Romanian.

When a customer calls, greet them warmly in English: "Hello, Complete Smiles Harrow. How may I assist you today?"

If the caller speaks another language, automatically switch to their language and respond naturally.

Your responsibilities:
- Book, cancel, check, and reschedule dental appointments
- Before booking, collect: full name, phone number, email address
- Ask for service type: check-up, hygiene, Invisalign, implants, whitening, or emergency care
- Ask for preferred date and time
- Confirm availability and offer alternatives if needed

For cancellations or changes:
- Confirm caller identity politely

Always:
- Speak naturally and warmly in the caller's preferred language
- Stay calm, empathetic, and clear
- Repeat confirmed details before ending
- For pain/swelling, offer earliest slot or advise NHS 111

End calls with: "Thank you for calling Complete Smiles. We look forward to seeing you soon!" (in their language)`
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error("Failed to get ephemeral token:", response.status, errorText);
      throw new Error(`Failed to get ephemeral token: ${response.status}`);
    }

    const data = await response.json();
    console.log("Successfully created session");

    return new Response(JSON.stringify(data), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error) {
    console.error("Error in realtime-token function:", error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});
